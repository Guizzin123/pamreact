import React, { useState } from 'react';
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  StyleSheet,
} from 'react-native';

const Tela = () => {
  const [n1, setN1] = useState('');
  const [n2, setN2] = useState('');
  const [resultado, setResultado] = useState('');

  const handleLogin = () => {

    const num1 = parseFloat(n1);
    const num2 = parseFloat(n2);

    const soma = num1 + num2;
    setResultado(`Resultado: ${soma}`);
  };

  return (
    <View style={styles.container}>
      <Text style={styles.text}>Calculadora plus </Text>
      <TextInput
        placeholder="Insira um número"
        style={styles.input}
        value={n1}
        onChangeText={setN1}
        keyboardType="numeric"
      />
      <TextInput
        placeholder="Insira outro número"
        style={styles.input}
        value={n2}
        onChangeText={setN2}
        keyboardType="numeric"
      />
      <TouchableOpacity onPress={handleLogin} style={styles.button}>
        <Text style={styles.buttonText}>Somar</Text>
      </TouchableOpacity>
      <Text style={styles.resultText}>{resultado}</Text>
    </View>
  );
};

const App = () => {
  return <Tela />;
};

const styles = StyleSheet.create({
  container: {
    flex: 1,
    justifyContent: 'center',
    alignItems: 'center',
  },
  input: {
    width: '80%',
    height: 40,
    borderColor: '',
    borderWidth: 1,
    marginVertical: 10,
    paddingHorizontal: 10,
    borderRadius: 50,

  },
  button: {
    backgroundColor: 'green',
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 5,
  },
  buttonText: {
    color: 'white',
    fontWeight: 'bold',
  },
  resultText: {
    marginTop: 20,
    fontSize: 18,
    fontWeight: 'bold',
    color: 'blue',
  },
  text: {
    fontSize: 20,
    fontWeight: 'bold',
    color: 'blue',
    textAlign: 'center',
    marginTop: 20,
  },
});

export default App;
